var searchData=
[
  ['font_0',['font',['../class_info.html#a8d8bfd190038c3ca520bbae9eda75050',1,'Info']]],
  ['frame_1',['frame',['../class_explosion.html#ab074829325183f50a3d1fb8f440f850e',1,'Explosion']]]
];
