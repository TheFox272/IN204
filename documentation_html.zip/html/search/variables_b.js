var searchData=
[
  ['max_5flife_0',['max_life',['../class_entity.html#a06fc93c44e32abffb6ae112358247d11',1,'Entity']]],
  ['music_1',['music',['../class_game.html#a01f031862741d01bf1a7649d4a0627a1',1,'Game']]]
];
