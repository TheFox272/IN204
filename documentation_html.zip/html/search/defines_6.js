var searchData=
[
  ['purple_0',['PURPLE',['../main_8cpp.html#a0bb0b009e7a7390473ace4d98bd843c0',1,'main.cpp']]]
];
