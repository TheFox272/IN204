var searchData=
[
  ['none_0',['NONE',['../entities_8hpp.html#ad2af16bf27c1b83797f1c32686caf1a3ab50339a10e1de285ac99d4c3990b8693',1,'entities.hpp']]],
  ['nroads_1',['nRoads',['../game_8cpp.html#a89258f5a74a325a1dc1304ba5303c774',1,'game.cpp']]]
];
