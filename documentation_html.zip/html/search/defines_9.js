var searchData=
[
  ['tank_5fspeed_0',['tank_speed',['../entities_8hpp.html#a46746eda234519f61ed523a3a5cd7c0a',1,'entities.hpp']]],
  ['thrustspeed_1',['thrustSpeed',['../entities_8hpp.html#a7f9a5de14c9e9568fb5875b56bebc561',1,'entities.hpp']]]
];
