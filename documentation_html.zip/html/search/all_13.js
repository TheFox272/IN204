var searchData=
[
  ['yellow_0',['YELLOW',['../main_8cpp.html#abf681265909adf3d3e8116c93c0ba179',1,'main.cpp']]]
];
