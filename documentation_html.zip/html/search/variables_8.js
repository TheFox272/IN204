var searchData=
[
  ['inertia_0',['inertia',['../class_entity.html#a81a0788643c42c4a8f3420f0ed4ca682',1,'Entity']]],
  ['is_5fdisplayed_1',['is_displayed',['../class_explosion.html#a2847fbfadaafdaaeb7b44dc05b4c6ac5',1,'Explosion']]],
  ['is_5fp1_2',['is_p1',['../class_player.html#a0e90340dd659974fc7f1481aed890314',1,'Player']]],
  ['isplayer1_3',['isPlayer1',['../class_hp_bar.html#aa440374980a3813669cb2f82aac957a9',1,'HpBar']]]
];
