var searchData=
[
  ['life_0',['life',['../class_entity.html#a7d0138546e29a073b6a31a65b8e78075',1,'Entity']]],
  ['loselife_1',['loseLife',['../class_entity.html#a2a5befd00c075a88e6a5f8dd3b127e74',1,'Entity']]]
];
