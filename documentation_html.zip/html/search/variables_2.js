var searchData=
[
  ['changechance_0',['changeChance',['../class_game.html#a5ed55fc4bfd8df092a0f5e319978b3dd',1,'Game']]],
  ['currenttile_1',['currentTile',['../class_game.html#a6a2c5dd506e89bbca4c36ab8e85fd18b',1,'Game']]]
];
