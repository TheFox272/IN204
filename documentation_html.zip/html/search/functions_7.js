var searchData=
[
  ['loselife_0',['loseLife',['../class_entity.html#a2a5befd00c075a88e6a5f8dd3b127e74',1,'Entity']]]
];
