var searchData=
[
  ['checkcollision_0',['checkCollision',['../class_game.html#a40cc2a030e3550d0e4ce4d293f7ab4e9',1,'Game']]],
  ['checkdeath_1',['checkDeath',['../class_game.html#aa3ebcf6c8e46e09d800de9c4a33d99e2',1,'Game']]]
];
