var searchData=
[
  ['changechance_0',['changeChance',['../class_game.html#a5ed55fc4bfd8df092a0f5e319978b3dd',1,'Game']]],
  ['checkcollision_1',['checkCollision',['../class_game.html#a40cc2a030e3550d0e4ce4d293f7ab4e9',1,'Game']]],
  ['checkdeath_2',['checkDeath',['../class_game.html#aa3ebcf6c8e46e09d800de9c4a33d99e2',1,'Game']]],
  ['currenttile_3',['currentTile',['../class_game.html#a6a2c5dd506e89bbca4c36ab8e85fd18b',1,'Game']]],
  ['cyan_4',['CYAN',['../main_8cpp.html#ad243f93c16bc4c1d3e0a13b84421d760',1,'main.cpp']]]
];
