var searchData=
[
  ['gamename_0',['gameName',['../display_8cpp.html#a66595485e30f7796acad87c9d741a635',1,'display.cpp']]],
  ['green_1',['GREEN',['../main_8cpp.html#acfbc006ea433ad708fdee3e82996e721',1,'main.cpp']]]
];
