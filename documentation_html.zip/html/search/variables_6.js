var searchData=
[
  ['gameover_0',['gameover',['../class_game.html#aad66e2f44bebad41743ea8f44a8778a5',1,'Game']]],
  ['gen_1',['gen',['../class_game.html#ad3432606974cc4ba33145b730d89bc1e',1,'Game']]]
];
